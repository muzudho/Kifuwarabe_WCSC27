using System;

namespace Test{
	public class Test{
		public static void Main(){
			string S = Console.ReadLine();
			Console.WriteLine("Phase: 1/4");
			System.Threading.Thread.Sleep(1000);
			Console.WriteLine("Phase: 2/4");
			System.Threading.Thread.Sleep(1000);
			Console.WriteLine("Phase: 3/4");
			System.Threading.Thread.Sleep(1000);
			Console.WriteLine("Phase: 4/4");
			System.Threading.Thread.Sleep(1000);
			Console.WriteLine("Your input: "+ S);

		}
	}
}

